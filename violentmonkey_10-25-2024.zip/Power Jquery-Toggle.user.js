// ==UserScript==
// @name        Power Jquery-Toggle
// @namespace   https://4ndr0666.github.io/
// @description Adds a button to toggle jQuery on or off for better site security and performance.
// @include     *
// @grant       none
// @version     1.0
// @author      4ndr0666
// ==/UserScript==
(function() {
    'use strict';

    // Function to disable jQuery
    function disableJQuery() {
        if (window.hasOwnProperty("$")) {
            window.$ = null;
        }
        if (window.hasOwnProperty("jQuery")) {
            window.jQuery = null;
        }
        console.log('jQuery has been disabled.');
    }

    // Function to enable jQuery (restore the original jQuery)
    function enableJQuery() {
        if (typeof originalJQuery !== 'undefined') {
            window.$ = originalJQuery;
            window.jQuery = originalJQuery;
            console.log('jQuery has been restored.');
        }
    }

    // Save the original jQuery
    let originalJQuery = window.jQuery;

    // Create a toggle button
    const toggleButton = document.createElement('button');
    toggleButton.innerHTML = 'Toggle jQuery';
    toggleButton.style.position = 'fixed';
    toggleButton.style.top = '10px';
    toggleButton.style.right = '10px';
    toggleButton.style.zIndex = '9999';
    toggleButton.style.padding = '8px';  // 20% smaller
    toggleButton.style.backgroundColor = '#151515';
    toggleButton.style.color = '#15FFFF';
    toggleButton.style.border = 'none';
    toggleButton.style.borderRadius = '5px';
    toggleButton.style.cursor = 'pointer';
    toggleButton.style.fontSize = '80%';  // 20% smaller
    toggleButton.style.opacity = '0.7';  // 70% opacity
    toggleButton.style.transition = 'opacity 0.3s ease';

    // Flag to keep track of jQuery state
    let isJQueryDisabled = false;

    // Timeout for hiding the button
    let hideTimeout;

    // Toggle jQuery on button click
    toggleButton.addEventListener('click', function() {
        if (isJQueryDisabled) {
            enableJQuery();
        } else {
            disableJQuery();
        }
        isJQueryDisabled = !isJQueryDisabled;
    });

    // Show button on hover
    toggleButton.addEventListener('mouseover', function() {
        clearTimeout(hideTimeout);
        toggleButton.style.opacity = '1';
    });

    // Hide button after 300ms when not hovering
    toggleButton.addEventListener('mouseout', function() {
        hideTimeout = setTimeout(function() {
            toggleButton.style.opacity = '0'; // Hides the button completely
        }, 300);
    });

    // Add the button to the document
    document.body.appendChild(toggleButton);
})();
