// ==UserScript==
// @name        Power Media-Handler
// @namespace   https://4ndr0666.github.io/
// @version     3.1
// @description Enables video englargement button and automatically reloads all broken images.
// @author      4ndr0666
// @include     *
// @grant       none
// @run-at      document-end
// @license     MIT
// ==/UserScript==

(function() {
    'use strict';

    /**
     * Module: ImageHandler
     * Description: Handles reloading of broken images on the page.
     */
    const ImageHandler = (() => {

        function reloadBrokenImages() {
            for (const img of document.images) {
                if (!img.complete || img.naturalHeight === 0) {
                    img.src = img.src.split('#')[0] + "#"; // Forces image reload
                }
            }
        }

        function broadcastReload() {
            for (const frame of window.frames) {
                frame.postMessage("RELOAD_BROKEN_IMAGES", "*");
            }
        }

        function init() {
            window.addEventListener("keyup", e => {
                if (e.key === 'r' && e.altKey) {
                    reloadBrokenImages();
                    broadcastReload();
                }
            });

            window.addEventListener("message", e => {
                if (e.data === "RELOAD_BROKEN_IMAGES") {
                    reloadBrokenImages();
                    broadcastReload();
                }
            });
        }

        return {
            init
        };
    })();

    /**
     * Module: MediaHandler
     * Description: Manages media maximization and video control buttons.
     */
    const MediaHandler = (() => {

        function maximizeMedia() {
            const video = document.querySelector("video");
            if (video) {
                if (video.requestFullscreen) {
                    video.requestFullscreen();
                } else if (video.webkitRequestFullscreen) {
                    video.webkitRequestFullscreen();
                } else if (video.mozRequestFullScreen) {
                    video.mozRequestFullScreen();
                } else if (video.msRequestFullscreen) {
                    video.msRequestFullscreen();
                } else {
                    console.error("Fullscreen API is not supported.");
                }
            } else {
                console.warn("No video element found to maximize.");
            }
        }

function createControlButton(text, onClick) {
    const button = document.createElement('button');
    button.innerHTML = text;

            // Initial styling, button is completely invisible until hover
            button.style.position = 'absolute';
            button.style.top = '10px';
            button.style.right = '10px';
            button.style.zIndex = '9999';
            button.style.padding = '4px 7px'; // Adjusted padding to better match text height
            button.style.backgroundColor = '#151515';
            button.style.color = '#15FFFF';
            button.style.border = '1px solid #15FFFF'; // Thinnest possible border
            button.style.borderRadius = '5px';
            button.style.cursor = 'pointer';
            button.style.fontSize = '70%';
            button.style.opacity = '0'; // Initially hidden
            button.style.transition = 'opacity 0.3s ease';

            let hideTimeout;

            // Show button on hover and hide after mouseout with a delay
            button.addEventListener('mouseover', () => {
                clearTimeout(hideTimeout);
                button.style.opacity = '1'; // Show button on hover
            });

            button.addEventListener('mouseout', () => {
                hideTimeout = setTimeout(() => {
                    button.style.opacity = '0'; // Hide button after mouseout
                }, 300);
            });

            button.addEventListener('click', onClick);

            return button;
        }


        function attachButtonToVideo(video) {
            const button = createControlButton('Maximize', maximizeMedia);
            video.parentElement.style.position = 'relative'; // Ensure the parent is relative to position the button correctly
            video.parentElement.appendChild(button);
        }

        function init() {
            const videos = document.querySelectorAll("video");
            if (videos.length > 0) {
                videos.forEach(video => {
                    attachButtonToVideo(video);
                });
            } else {
                console.warn("No video elements found on the page.");
            }
        }

        return {
            init
        };
    })();

    /**
     * Initialization: Set up both ImageHandler and MediaHandler
     */
    function init() {
        ImageHandler.init(); // Initialize image handling functionalities
        MediaHandler.init(); // Initialize media maximization functionalities
    }

    // Run initialization
    init();

    /**
     * Error handling and logging
     * Ensures smooth execution and debugging.
     */
    window.addEventListener('error', function(event) {
        console.error('An error occurred:', event.message, 'at', event.filename, ':', event.lineno);
    });

})();
