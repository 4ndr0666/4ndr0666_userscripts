// ==UserScript==
// @name         Power Website Tweaks
// @namespace    https://4ndr0666.github.io/
// @include      *
// @grant        none
// @version      1.0
// @author       4ndr0666
// @description  Universal website improvements by moderninzing lazy loading, debouncing, preloading and optimizing resources.
// @run-at       document-start
// ==/UserScript==

(() => {
    'use strict';

    // Centralized error logging function
    const logError = (message, error) => {
        console.error(`[Website Performance Tweaks] ${message}`, error);
    };

    // Blocklist for third-party resources that slow down the page
    const blockPatterns = [
        /google\.analytics\.com/, /analytics\.js/, /gtag\/js/,
        /doubleclick\.net/, /adsbygoogle\.js/, /googlesyndication\.com/,
        /googletagmanager\.com/, /facebook\.net/, /fbevents\.js/,
        /scorecardresearch\.com/, /quantserve\.com/, /amazon-adsystem\.com/,
        /adnxs\.com/, /criteo\.net/, /outbrain\.com/, /taboola\.com/
    ];

    // Debounce function to limit the rate of function execution
    const debounce = (func, wait) => {
        let timeout;
        return (...args) => {
            clearTimeout(timeout);
            timeout = setTimeout(() => func(...args), wait);
        };
    };

    // Function to intercept and block unwanted requests
    const interceptRequests = () => {
        // Intercept XMLHttpRequest
        const originalOpen = XMLHttpRequest.prototype.open;
        XMLHttpRequest.prototype.open = function(method, url, ...args) {
            if (!blockPatterns.some(pattern => pattern.test(url))) {
                return originalOpen.apply(this, [method, url, ...args]);
            }
        };

        // Intercept Fetch API
        const originalFetch = window.fetch;
        window.fetch = function(input, init) {
            if (typeof input === 'string' && blockPatterns.some(pattern => pattern.test(input))) {
                return Promise.reject(new Error('Request blocked by Userscript'));
            }
            return originalFetch.call(this, input, init);
        };

        // Use debounce for mutation handling to optimize performance
        const handleMutations = debounce(mutations => {
            mutations.forEach(({ addedNodes }) => {
                addedNodes.forEach(node => {
                    if (node.nodeType === Node.ELEMENT_NODE) {
                        const tagName = node.tagName.toLowerCase();
                        if ((tagName === 'script' || tagName === 'link') &&
                            blockPatterns.some(pattern => pattern.test(node.src || node.href))) {
                            node.remove();
                        }
                    }
                });
            });
        }, 100);

        // Observe DOM changes to block dynamically added resources
        new MutationObserver(handleMutations).observe(document.body, { childList: true, subtree: true });
    };

    // Improved lazy loading function for images
    const enhancedLazyLoad = () => {
        const lazyLoadAttributes = ['data-src', 'data-lazy', 'data-original', 'data-srcset'];

        const loadImage = (image) => {
            lazyLoadAttributes.forEach(attr => {
                const dataSrc = image.getAttribute(attr);
                if (dataSrc) {
                    image.setAttribute(attr.replace('data-', ''), dataSrc);
                    image.removeAttribute(attr);
                }
            });
        };

        // IntersectionObserver to handle lazy loading when images are in view
        const observer = new IntersectionObserver(entries => {
            entries.forEach(entry => {
                if (entry.isIntersecting) {
                    loadImage(entry.target);
                    observer.unobserve(entry.target);
                }
            });
        }, { threshold: 0.1 });

        // Observe images with lazy load attributes
        document.querySelectorAll('img').forEach(img => {
            if (lazyLoadAttributes.some(attr => img.hasAttribute(attr))) {
                observer.observe(img);
            }
        });
    };

    // Preload critical resources to improve performance
    const preloadCriticalResources = () => {
        const preloadLinks = new Set();

        // Preload critical images
        document.querySelectorAll('img[data-critical], link[rel="stylesheet"][data-critical="true"]').forEach(resource => {
            const link = document.createElement('link');
            link.rel = 'preload';
            link.as = resource.tagName.toLowerCase() === 'img' ? 'image' : 'style';
            link.href = resource.src || resource.href;
            preloadLinks.add(link);
        });

        // Append all preload links to the head of the document
        preloadLinks.forEach(link => document.head.appendChild(link));
    };

    // Replace document.write with safer alternatives
    const replaceDocumentWrite = () => {
        const handleContentInsertion = content => {
            try {
                document.body.insertAdjacentHTML('beforeend', content);
            } catch (err) {
                logError('Failed to insert content:', err);
            }
        };

        // Override document.write and document.writeln to prevent blocking rendering
        document.write = document.writeln = (content) => {
            if (typeof content === 'string') {
                handleContentInsertion(content);
            } else {
                logError('Content must be a string.');
            }
        };
    };

    // Clean up unnecessary HTML elements to reduce page bloat
    const cleanupHTMLElements = () => {
        const metaTagBlacklist = ['keywords', 'description', 'author', 'generator', 'robots', 'googlebot'];
        const scriptBlacklist = ['google-analytics', 'googletagmanager', 'adsbygoogle', 'doubleclick.net'];

        // Remove blacklisted META tags
        document.querySelectorAll('meta[name], meta[property], meta[http-equiv]').forEach(meta => {
            const attr = meta.getAttribute('name') || meta.getAttribute('property') || meta.getAttribute('http-equiv');
            if (metaTagBlacklist.some(blacklisted => attr && attr.toLowerCase().includes(blacklisted))) {
                meta.remove();
            }
        });

        // Remove blacklisted SCRIPT tags
        document.querySelectorAll('script[src]').forEach(script => {
            if (scriptBlacklist.some(blacklisted => script.src.includes(blacklisted))) {
                script.remove();
            }
        });

        // Remove all <noscript> tags to streamline the DOM
        document.querySelectorAll('noscript').forEach(noscript => noscript.remove());
    };

    // Enable YouTube privacy mode by replacing standard embed URLs with no-cookie variants
    const enableYouTubePrivacyMode = () => {
        document.querySelectorAll('iframe[src*="youtube.com/embed/"]').forEach(iframe => {
            iframe.src = iframe.src.replace('youtube.com/embed/', 'youtube-nocookie.com/embed/');
        });
    };

    // Perform optimizations that should run immediately upon script execution
    const immediateOptimizations = () => {
        try {
            interceptRequests();
            replaceDocumentWrite();
            preloadCriticalResources();
        } catch (error) {
            logError('Error during immediate optimizations:', error);
        }
    };

    // Perform optimizations after the DOM content is fully loaded
    const domContentLoadedOptimizations = () => {
        try {
            enhancedLazyLoad();
            cleanupHTMLElements();
            enableYouTubePrivacyMode();
        } catch (error) {
            logError('Error during DOM content loaded optimizations:', error);
        }
    };

    // Execute immediate optimizations
    immediateOptimizations();

    // Ensure DOM content loaded optimizations run at the appropriate time
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', domContentLoadedOptimizations);
    } else {
        domContentLoadedOptimizations();
    }
})();
