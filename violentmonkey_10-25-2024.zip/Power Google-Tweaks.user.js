// ==UserScript==
// @name        Power Google-Tweaks
// @namespace   https://4ndr0666.github.io/
// @description Removes tracking elements from Google search results, strips UTM parameters, and prevents unwanted redirection tracking.
// @include     *
// @grant       none
// @version     1.1
// @run-at      document-start
// @author      4ndr0666
// ==/UserScript==

(function() {
    'use strict';

    /**
     * Safely disable Google's redirection tracking function
     * Ensures that the rwt function cannot be overwritten or re-enabled
     */
    const disableGoogleTracking = () => {
        try {
            Object.defineProperty(window, 'rwt', {
                value: function() {},
                writable: false,
                configurable: false
            });
            console.log('[Privacy Enhancer] Google redirection tracking disabled.');
        } catch (error) {
            console.error('[Privacy Enhancer] Failed to disable Google redirection tracking:', error);
        }
    };

    /**
     * Cleans up Google search result URLs by removing redirection tracking parameters
     * Targets Google search result links and ensures they point directly to the destination
     */
    const cleanGoogleSearchLinks = () => {
        try {
            const selectors = ['.cleanslate a[href^="/url"]', '#desktop-search .r a'];
            selectors.forEach(selector => {
                const results = document.querySelectorAll(selector);
                results.forEach(link => {
                    let url = new URL(link.href);
                    let actualUrl = url.searchParams.get('q');
                    if (actualUrl) {
                        link.href = actualUrl;
                    }
                });
            });
            console.log('[Privacy Enhancer] Google search result links cleaned.');
        } catch (error) {
            console.error('[Privacy Enhancer] Failed to clean Google search links:', error);
        }
    };

    /**
     * Removes UTM parameters from the current URL
     * Strips tracking parameters and updates the URL without reloading the page
     */
    const removeUtmParams = () => {
        try {
            const search = document.location.search;
            if (search) {
                const newSearch = search.replace(/utm_[a-z]+=(.*?)(&|$)/g, '').replace(/[\?&]$/, '');
                if (newSearch !== search) {
                    const newUrl = document.location.href.replace(search, newSearch);
                    history.replaceState({}, document.title, newUrl);
                    console.log('[Privacy Enhancer] UTM parameters removed.');
                }
            }
        } catch (error) {
            console.error('[Privacy Enhancer] Failed to remove UTM parameters:', error);
        }
    };

    /**
     * Initializes the MutationObserver to monitor and clean Google search result links
     * Observes the body for added nodes to ensure links are cleaned dynamically
     */
    const observeMutations = () => {
        try {
            const observer = new MutationObserver(mutations => {
                mutations.forEach(mutation => {
                    if (mutation.addedNodes.length > 0) {
                        cleanGoogleSearchLinks();
                    }
                });
            });
            observer.observe(document.body, { childList: true, subtree: true });
            console.log('[Privacy Enhancer] MutationObserver initialized.');
        } catch (error) {
            console.error('[Privacy Enhancer] Failed to initialize MutationObserver:', error);
        }
    };

    /**
     * Initializes the script by executing all necessary functions on page load
     * Ensures that tracking elements are removed and links are cleaned as soon as possible
     */
    const init = () => {
        disableGoogleTracking();
        cleanGoogleSearchLinks();
        removeUtmParams();
        observeMutations();
    };

    // Run the initialization function after the DOM is fully loaded
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }
})();
