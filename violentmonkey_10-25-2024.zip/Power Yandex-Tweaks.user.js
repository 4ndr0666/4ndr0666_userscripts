// ==UserScript==
// @name        Power Yandex-Tweaks
// @namespace   https://4ndr0666.github.io/
// @match       *://yandex.com/*
// @match       *://yandex.ru/*
// @match       *://yandex.by/*
// @match       *://yandex.kz/*
// @match       *://yandex.ua/*
// @match       *://yandex.uz/*
// @match       *://yandex.com.tr/*
// @match       *://yandex.tj/*
// @match       *://yandex.am/*
// @match       *://yandex.az/*
// @match       *://yandex.ge/*
// @match       *://yandex.net/*
// @match       *://yandex.tld/*
// @match       *://*.yandex.com/*
// @match       *://*.yandex.ru/*
// @match       *://*.yandex.by/*
// @match       *://*.yandex.kz/*
// @match       *://*.yandex.ua/*
// @match       *://*.yandex.uz/*
// @match       *://*.yandex.com.tr/*
// @match       *://*.yandex.tj/*
// @match       *://*.yandex.am/*
// @match       *://*.yandex.az/*
// @match       *://*.yandex.ge/*
// @match       *://*.yandex.net/*
// @match       *://*.yandex.tld/*
// @match       *://*.turbopages.org/*
// @grant       none
// @version     1.1
// @author      4ndr0666
// @description Removes Yandex bloat from redirection, Turbo, and ads; adds automated image search UI.
// @run-at      document-start
// ==/UserScript==

(function() {
    'use strict';

    // Constants
    const TIMEOUT_MS = 1500;
    let playing = false;
    let timeout;

    /**
     * Clicks the next image button on the page.
     */
    function clickNext() {
        try {
            const nextButton = document.querySelector(".CircleButton_type_next");
            if (nextButton) nextButton.click();
        } catch (error) {
            console.error('[Yandex Upgraded] Error clicking next image:', error);
        }
    }

    /**
     * Toggles automatic image sliding with Up Arrow key.
     */
    function toggleAutoSlide() {
        playing = !playing;
        if (playing) {
            timeout = setInterval(clickNext, TIMEOUT_MS);
            console.log('[Yandex Upgraded] Auto-slide started.');
        } else {
            clearInterval(timeout);
            console.log('[Yandex Upgraded] Auto-slide stopped.');
        }
    }

    /**
     * Removes Yandex redirections from search results.
     * @param {Element} element - The DOM element to scan for redirects.
     */
    function removeYandexRedirects(element) {
        try {
            const links = element.querySelectorAll('a[onmousedown*="/clck/jsredir"], a[data-counter], a[data-vdir-href]');
            links.forEach(link => {
                link.removeAttribute('onmousedown');
                link.removeAttribute('data-counter');
                link.removeAttribute('data-bem');
                link.removeAttribute('data-vdir-href');
                link.removeAttribute('data-orig-href');
            });
        } catch (error) {
            console.error('[Yandex Upgraded] Error removing Yandex redirects:', error);
        }
    }

    /**
     * Observes and dynamically removes Yandex redirects as they are added to the DOM.
     */
    function observeRedirects() {
        try {
            const observer = new MutationObserver(mutations => {
                mutations.forEach(mutation => {
                    mutation.addedNodes.forEach(node => {
                        if (node.nodeType === Node.ELEMENT_NODE) {
                            removeYandexRedirects(node);
                        }
                    });
                });
            });
            observer.observe(document.body, { childList: true, subtree: true });
            console.log('[Yandex Upgraded] Mutation observer for redirects initialized.');
        } catch (error) {
            console.error('[Yandex Upgraded] Error initializing MutationObserver:', error);
        }
    }

    /**
     * Redirects from Yandex Turbo pages to the original URL.
     */
    function avoidYandexTurbo() {
        try {
            const turboScript = document.querySelector('script[data-name="post-message"][data-message]');
            if (turboScript) {
                const dataMessage = JSON.parse(turboScript.getAttribute('data-message') || '{}');
                if (dataMessage.originalUrl) {
                    console.log('[Yandex Upgraded] Redirecting from Turbo page to original URL.');
                    top.location.replace(dataMessage.originalUrl);
                }
            }
        } catch (error) {
            console.error('[Yandex Upgraded] Error avoiding Yandex Turbo pages:', error);
        }
    }

    /**
     * Highlights and hides unwanted search results based on domain name.
     */
    function highlightAndFilterResults() {
        try {
            const targetDomains = ['alpha-t.org', 'alpha-t.ru', 'agp24.ru', 'agrp24.ru', 'ypb24.ru', 'remontika-24.ru', 'remontika38.ru', 'alpha-irk.ru', 'sanek508.net'];
            let start = 1;

            document.querySelectorAll(".serp-item").forEach(item => {
                if (item.querySelector(".serp-adv__title-text")) {
                    item.style.display = 'none'; // Hide ads
                } else {
                    const title = item.querySelector(".serp-item__title, .organic__title-wrapper");
                    if (title) {
                        // Index the search results
                        const indexSpan = document.createElement("span");
                        indexSpan.textContent = `${start}. `;
                        indexSpan.style.cssText = "float:left;margin-left:-28px;padding-top:20px;";
                        title.insertBefore(indexSpan, title.firstChild);
                        start++;

                        // Highlight specific domains
                        targetDomains.forEach(domain => {
                            if (title.querySelector(`a[href*="${domain}"]`)) {
                                item.style.border = '1px solid #c4df9b';
                            }
                        });
                    }
                }
            });
            console.log('[Yandex Upgraded] Search results filtered and highlighted.');
        } catch (error) {
            console.error('[Yandex Upgraded] Error filtering search results:', error);
        }
    }

    /**
     * Inject custom styles to enhance the appearance of images.
     */
    function injectStyles() {
        try {
            const styleSheet = document.createElement('style');
            styleSheet.innerHTML = `
                .MMImageContainer, .MMImage-Preview {
                    width: 100% !important;
                    height: 100% !important;
                    background: black !important;
                }
            `;
            document.head.appendChild(styleSheet);
            console.log('[Yandex Upgraded] Custom styles injected.');
        } catch (error) {
            console.error('[Yandex Upgraded] Error injecting custom styles:', error);
        }
    }

    /**
     * Initialization function to execute all necessary functions.
     */
    function init() {
        removeYandexRedirects(document.body);
        observeRedirects();
        avoidYandexTurbo();
        highlightAndFilterResults();
        injectStyles();
    }

    // Event Listeners
    document.addEventListener('keydown', (e) => {
        if (e.keyCode === 38) toggleAutoSlide(); // Up Arrow to toggle image auto-slide
    });

    // Run initialization
    init();

})();
