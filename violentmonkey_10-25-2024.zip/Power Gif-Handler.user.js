// ==UserScript==
// @name        Power Gif-Handler
// @namespace   https://4ndr0666.github.io/
// @version     2.0
// @author      4ndr0666
// @description Automatically upgrades SD gifs to HD, with enhanced playback control and display options.
// @match       *://*.gifdeliverynetwork.com/*
// @match       *://cdn.embedly.com/widgets/media.html?src=*://*.redgifs.com/*
// @match       *://*.redgifs.com/*
// @connect     *.redgifs.com
// @connect     *.gifdeliverynetwork.com
// @connect     *.cdn.embedly.com
// @connect     *.api.redgifs.com
// @grant       unsafeWindow
// @grant       GM.xmlHttpRequest
// @grant       GM_addStyle
// @grant       GM_download
// @run-at      document-start
// ==/UserScript==

(function() {
    'use strict';

    let initialized = false;

    /**
     * Injects the necessary CSS styles for the script.
     */
    function injectStyles() {
        try {
            const styles = `
                body.gfyHD { overflow: auto !important; }
                img {
                    transition: max-width 0.4s ease-in-out, max-height 0.4s ease-in-out;
                    max-width: 200px;
                    max-height: 200px;
                    object-fit: contain;
                }
                img:hover {
                    max-width: 100%;
                    max-height: 100%;
                }
            `;
            const styleSheet = document.createElement("style");
            styleSheet.type = "text/css";
            styleSheet.innerText = styles;
            document.head.appendChild(styleSheet);
        } catch (error) {
            console.error("Error injecting styles:", error);
        }
    }

    /**
     * Processes media entries to upgrade SD URLs to HD if available.
     * @param {Object} media - The media object containing URLs.
     */
    function processMediaEntry(media) {
        try {
            if (media?.urls?.hd) {
                media.urls.sd = media.urls.hd; // Replace SD with HD URL
                if (!media.urls.hd.includes('.mp4?')) {
                    media.urls.thumbnail = media.urls.hd;
                    media.urls.poster = media.urls.hd;
                }
            }
        } catch (error) {
            console.error("Error processing media entry:", error);
        }
    }

    /**
     * Intercepts XMLHttpRequest to modify responses containing media URLs.
     */
    function interceptRequests() {
        const originalOpen = XMLHttpRequest.prototype.open;
        XMLHttpRequest.prototype.open = function (method, url, ...args) {
            if (/\/v[1-3]\/.*\/gifs/.test(url)) {
                this.addEventListener('readystatechange', function (e) {
                    if (this.readyState === 4) {
                        try {
                            const content = JSON.parse(this.responseText);
                            if (content?.gif) {
                                processMediaEntry(content.gif);
                            } else if (content?.gifs) {
                                content.gifs.forEach(gif => processMediaEntry(gif));
                            }
                            this.responseText = JSON.stringify(content);
                        } catch (err) {
                            console.error("Error processing media entry:", err);
                        }
                    }
                });
            }
            originalOpen.call(this, method, url, ...args);
        };
    }

    /**
     * Handles JSON parsing to detect and render GIFs.
     * @param {string} json - The JSON string to parse.
     */
    function handleJSONParsing(json) {
        try {
            if (typeof json === 'string' && json.includes('"gif"')) {
                const parsed = JSON.parse(json);
                if (parsed?.gif?.urls) {
                    renderHDGif(parsed.gif);
                }
                return parsed;
            }
        } catch (error) {
            console.error("Error parsing JSON for GIFs:", error);
        }
        return JSON.parse(json);
    }

    /**
     * Renders the HD GIF in the document body.
     * @param {Object} gif - The GIF object containing URLs.
     */
    function renderHDGif(gif) {
        document.body.innerHTML = `
            <img src="${gif.urls.poster}" style="position: fixed; width: 100%; z-index: -1; filter: blur(90px);">
            <video controls src="${gif.urls.hd || gif.urls.sd}" poster="${gif.urls.poster}"
            style="max-height: calc(100vh - 20px); border-radius: 10px; cursor: pointer; max-width: calc(100vw - 20px);"></video>
        `;
        document.body.style = 'display: flex; justify-content: center; align-items: center; height: 100vh;';
    }

    /**
     * Overrides JSON.parse to include custom GIF rendering logic.
     */
    function overrideJSONParse() {
        const originalParse = JSON.parse;
        JSON.parse = function (json, ...args) {
            return handleJSONParsing(json) || originalParse(json, ...args);
        };
    }

    /**
     * Initializes the script by injecting styles and setting up request interception.
     */
    function init() {
        if (initialized) return; // Ensure idempotency
        initialized = true;

        injectStyles();
        interceptRequests();
        overrideJSONParse();

        console.log("HDify Gifs script initialized.");
    }

    // Initialize the script
    init();

    /**
     * User guidance for modifying URL patterns and styles.
     */
    console.info("To customize this script, modify the interceptRequests() and injectStyles() functions as needed.");
})();
