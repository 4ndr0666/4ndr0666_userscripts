// ==UserScript==
// @name         Power Link-Handler
// @namespace    https://4ndr0666.github.io/
// @version      2.0
// @description  Automatically bypasses external link confirmations, converts plain text URLs to clickable links, and opens all links in new tabs. Integrated with linkify to auto-link URLs.
// @author       4ndr0666
// @include      *
// @license      Public domain / no rights reserved
// @run-at       document-idle
// @grant        GM_addStyle
// @grant        GM_getValue
// @grant        GM_setValue
// @grant        GM_openInTab
// @grant        GM_notification
// @require      https://cdn.staticfile.org/jquery/3.7.1/jquery.min.js
// @require      https://raw.githubusercontent.com/maranomynet/linkify/master/1.0/jquery.linkify-1.0.js
// ==/UserScript==

(function () {
    'use strict';

    const $ = jQuery.noConflict(true);

    // Configuration section
    const config = {
        redirectPatterns: [
            { pattern: /\/goto\/link-confirmation\?url=([^&]+)/, param: 'url' },
            // Add more patterns here to customize redirection behavior
        ],
        enableLogging: GM_getValue('enableLogging', true), // Set to false to disable logging
        autoOpenInNewTab: true // Automatically opens all links in new tabs
    };

    // Logging utility
    function log(message) {
        if (config.enableLogging) {
            console.log(`[Power Link-Handler] ${message}`);
        }
    }

    // Handle link clicks and enforce opening in a new tab
    document.addEventListener('click', function(event) {
        const anchor = event.target.closest('a');
        if (anchor && anchor.href) {
            if (config.autoOpenInNewTab) {
                event.preventDefault();
                window.open(anchor.href, '_blank');
                log(`Opening link in a new tab: ${anchor.href}`);
            }
        }
    }, true);

    // Override window.open to ensure it opens URLs in a new tab
    const originalOpen = window.open;
    window.open = function(url, target = '_blank', features) {
        if (['_self', '_parent', '_top'].includes(target)) {
            target = '_blank';
        }
        log(`Overriding window.open to open in a new tab: ${url}`);
        return originalOpen.call(window, url, target, features);
    };

    // Automatic redirection based on URL patterns
    function handleRedirections() {
        const currentURL = window.location.href;
        for (const redirect of config.redirectPatterns) {
            const match = currentURL.match(redirect.pattern);
            if (match) {
                const targetURL = decodeURIComponent(match[1]);
                log(`Redirecting to: ${targetURL}`);
                window.location.replace(targetURL);
                break;
            }
        }
    }

    // Function to bypass confirmation dialogs by automatically clicking the confirmation button
    function bypassConfirmationDialog() {
        const confirmButton = document.querySelector('.button--cta > .button-text');
        if (confirmButton) {
            confirmButton.click();
            log('Automatically clicked the confirmation button.');
        } else {
            log('No confirmation button found.');
        }
    }

    // Convert plain text URLs to clickable links using linkify
//    function convertPlainTextURLs() {
//        $('body').linkify(); // Applies linkify to the entire body
 //       log('Applied linkify to convert plain text URLs into clickable links.');
 //   }

    // Initialize the script
    function init() {
//        log('Initializing Power Link-Handler...');
        handleRedirections();
        bypassConfirmationDialog(); // Added here to ensure it runs after redirects
//        convertPlainTextURLs(); // Convert plain text URLs into clickable links
//        log('Initialization complete.');
    }

    // Run the initialization after the document is fully loaded
    window.addEventListener('load', init, false);

    // Error handling for unexpected issues
    window.addEventListener('error', function(event) {
        console.error(`[Power Link-Handler] Error occurred: ${event.message}`);
        GM_notification({
            text: `An error occurred: ${event.message}`,
            title: 'Power Link-Handler Error',
            timeout: 5000,
            onclick: function() {
                window.open('https://github.com/your-repo/issues');
            }
        });
    });

    // User instructions and script details
    function showConfigUI() {
        GM_addStyle(`
            #power-link-handler-info {
                position: fixed;
                bottom: 10px;
                right: 10px;
                background: #f9f9f9;
                border: 1px solid #ddd;
                padding: 10px;
                z-index: 1000;
                font-size: 12px;
                display: none; /* Hidden by default */
            }
            #power-link-handler-info button {
                margin-top: 5px;
                padding: 5px 10px;
                font-size: 12px;
            }
        `);

        const infoBox = document.createElement('div');
        infoBox.id = 'power-link-handler-info';
        infoBox.innerHTML = `
            <strong>Power Link-Handler</strong><br>
            This script automatically manages external links and text URLs.<br>
            <button id="power-link-handler-config">Configure</button>
        `;
        document.body.appendChild(infoBox);

        document.getElementById('power-link-handler-config').addEventListener('click', function() {
            const enableLogging = confirm('Enable logging?');
            GM_setValue('enableLogging', enableLogging);
            config.enableLogging = enableLogging;
            log('Configuration updated.');
        });
    }

    // Show the configuration UI only when the user requests it
    function toggleConfigUI() {
        const infoBox = document.getElementById('power-link-handler-info');
        if (infoBox) {
            infoBox.style.display = infoBox.style.display === 'none' ? 'block' : 'none';
        }
    }

    // Add a keyboard shortcut (Ctrl+Shift+L) to toggle the configuration UI
    document.addEventListener('keydown', function(event) {
        if (event.ctrlKey && event.shiftKey && event.code === 'KeyL') {
            toggleConfigUI();
        }
    });

    showConfigUI();

})();
