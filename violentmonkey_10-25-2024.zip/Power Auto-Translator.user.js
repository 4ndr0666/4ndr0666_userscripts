// ==UserScript==
// @name        Power Auto-Translator
// @namespace   https://4ndr0666.github.io/
// @description Automatically translates Chinese, Japanese, Spanish, German, and Russian to English, with no extra bloat.
// @grant       none
// @version     1.0
// @match       *://*/*
// @author      4ndr0666
// ==/UserScript==
(function() {
    'use strict';

    // List of languages to translate to English
    const languages = ['zh', 'zh-TW', 'ja', 'es', 'de', 'ru'];

    // Function to check the page language and translate if necessary
    function translatePage() {
        const lang = document.documentElement.lang || document.querySelector('meta[http-equiv="Content-Language"]')?.content;

        if (languages.includes(lang)) {
            // Trigger the built-in browser translation feature
            if (window.google && window.google.translate) {
                window.google.translate.translatePage('auto', 'en');
            } else {
                // Redirect to Google Translate if the browser doesn't support in-page translation
                const currentURL = window.location.href;
                window.location.href = `https://translate.google.com/translate?hl=en&sl=auto&tl=en&u=${encodeURIComponent(currentURL)}`;
            }
        }
    }

    // Execute translation
    translatePage();
})();
