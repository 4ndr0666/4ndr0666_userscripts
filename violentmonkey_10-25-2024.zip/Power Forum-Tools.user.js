// ==UserScript==
// @name        Power Forum-Tools
// @namespace   https://4ndr0666.github.io/
// @version     2.0
// @description Enhanced script for downloading images and videos directly from forum posts with improved error handling and modular design.
// @match       *://*.xenforo.com/*
// @match       *://*.simpcity.su*
// @connect     *
// @grant       GM.xmlHttpRequest
// @grant       GM_download
// @grant       GM_addStyle
// @run-at      document-idle
// ==/UserScript==

(function () {
    'use strict';

    // Ensure the script initializes only once
    let initialized = false;
    if (initialized) return;
    initialized = true;

    /**
     * Injects custom styles into the page for the downloader UI.
     */
    function injectStyles() {
        try {
            const styles = `
                .download-btn {
                    position: absolute;
                    top: 10px;
                    right: 10px;
                    background-color: #4CAF50;
                    color: white;
                    padding: 5px 10px;
                    border: none;
                    border-radius: 5px;
                    cursor: pointer;
                    z-index: 1000;
                }
                .download-btn:hover {
                    background-color: #45a049;
                }
                .download-container {
                    position: relative;
                }
            `;
            GM_addStyle(styles);
        } catch (error) {
            console.error("Error injecting styles:", error);
        }
    }

    /**
     * Adds a download button to media elements (images, videos) found in the post.
     * @param {Element} mediaElement - The media element (img, video) to attach the download button to.
     * @param {string} url - The URL of the media file to download.
     */
    function addDownloadButton(mediaElement, url) {
        try {
            const container = document.createElement('div');
            container.className = 'download-container';
            mediaElement.parentNode.insertBefore(container, mediaElement);
            container.appendChild(mediaElement);

            const button = document.createElement('button');
            button.className = 'download-btn';
            button.innerText = 'Download';
            button.addEventListener('click', () => downloadMedia(url));

            container.appendChild(button);
        } catch (error) {
            console.error("Error adding download button:", error);
        }
    }

    /**
     * Downloads a media file from the provided URL.
     * @param {string} url - The URL of the media file to download.
     */
    function downloadMedia(url) {
        try {
            GM_download({
                url: url,
                name: url.split('/').pop(),
                onerror: function (err) {
                    console.error("Download failed:", err);
                }
            });
        } catch (error) {
            console.error("Error downloading media:", error);
        }
    }

    /**
     * Processes all media elements in the document, adds download buttons to them.
     */
    function processMediaElements() {
        try {
            const mediaSelectors = ['img', 'video'];
            mediaSelectors.forEach(selector => {
                document.querySelectorAll(selector).forEach(media => {
                    const url = media.src || media.currentSrc;
                    if (url) {
                        addDownloadButton(media, url);
                    }
                });
            });
        } catch (error) {
            console.error("Error processing media elements:", error);
        }
    }

    /**
     * Initializes the script by injecting styles and processing media elements.
     */
    function init() {
        injectStyles();
        processMediaElements();
        console.log("Forum Media Downloader script initialized.");
    }

    // Initialize the script
    init();
})();
