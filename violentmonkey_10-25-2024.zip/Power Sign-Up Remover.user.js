// ==UserScript==
// @name        Power Sign-Up Remover
// @namespace   https://4ndr0666.github.io/
// @description Removes annoying sign-up prompts, overlays, and modals across various websites.
// @include     *
// @grant       none
// @version     1.1
// @author      4ndr0666
// @run-at      document-start
// ==/UserScript==

(function() {
    'use strict';

    // List of selectors that typically match sign-up prompts and ads
    const SELECTORS = [
        'a[href*="sign_up"]',
        'a[href*="premium"]',
        '.modal',
        '.overlay',
        'div[role="dialog"]',
        'div[class*="signup"]',
        'div[class*="premium"]'
    ];

    /**
     * Remove elements that match specified selectors.
     * @param {Array} selectors - List of CSS selectors to match against.
     */
    function removeSignUpAds(selectors) {
        selectors.forEach(selector => {
            const elements = document.querySelectorAll(selector);
            elements.forEach(element => {
                try {
                    // Check if the element or its closest parent can be removed
                    const parent = element.closest('div') || element.parentElement;
                    if (parent) {
                        parent.remove();
                    } else {
                        element.remove();
                    }
                } catch (error) {
                    console.error(`[Universal Sign-Up Ad Remover] Error removing element: ${error}`);
                }
            });
        });
    }

    /**
     * Initialize the script by running the ad removal and setting up a MutationObserver.
     */
    function init() {
        try {
            removeSignUpAds(SELECTORS);

            // Observe the DOM for changes and remove ads if new elements are added
            const observer = new MutationObserver(() => {
                removeSignUpAds(SELECTORS);
            });

            observer.observe(document.body, { childList: true, subtree: true });
            console.log('[Universal Sign-Up Ad Remover] Script initialized and observer set up.');
        } catch (error) {
            console.error(`[Universal Sign-Up Ad Remover] Initialization error: ${error}`);
        }
    }

    // Run the script once the DOM is ready
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', init);
    } else {
        init();
    }

    // Error handling for any unexpected issues
    window.addEventListener('error', function(event) {
        console.error('[Universal Sign-Up Ad Remover] An error occurred:', event.message);
    });

})();
