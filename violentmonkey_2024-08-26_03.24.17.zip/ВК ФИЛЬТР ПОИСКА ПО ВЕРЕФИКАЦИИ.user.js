// ==UserScript==
// @name         ВК ФИЛЬТР ПОИСКА ПО ВЕРЕФИКАЦИИ
// @namespace    http://tampermonkey.net/
// @version      1.1
// @description  Скрыть все сообщения, кроме верефецированых
// @author       Your Name
// @match        https://vk.com/search/*
// @grant        none
// @require      https://code.jquery.com/jquery-3.6.0.min.js
// @license MIT
// @downloadURL https://update.greasyfork.org/scripts/497444/%D0%92%D0%9A%20%D0%A4%D0%98%D0%9B%D0%AC%D0%A2%D0%A0%20%D0%9F%D0%9E%D0%98%D0%A1%D0%9A%D0%90%20%D0%9F%D0%9E%20%D0%92%D0%95%D0%A0%D0%95%D0%A4%D0%98%D0%9A%D0%90%D0%A6%D0%98%D0%98.user.js
// @updateURL https://update.greasyfork.org/scripts/497444/%D0%92%D0%9A%20%D0%A4%D0%98%D0%9B%D0%AC%D0%A2%D0%A0%20%D0%9F%D0%9E%D0%98%D0%A1%D0%9A%D0%90%20%D0%9F%D0%9E%20%D0%92%D0%95%D0%A0%D0%95%D0%A4%D0%98%D0%9A%D0%90%D0%A6%D0%98%D0%98.meta.js
// ==/UserScript==

(function($) {
    'use strict';

    // Function to hide unverified posts
    function hideUnverifiedPosts() {
        $('div._post.post.page_block.post--withPostBottomAction.post--with-likes.closed_comments.deep_active.Post--redesign').each(function() {
            const post = $(this);
            const isVerified = post.find('a[href="/verify"]').length > 0;
            if (!isVerified) {
                console.log(`Hiding post with ID: ${post.data('post-id')}`);
                post.hide();
            }
        });
    }

    // Function to click "Show More" button
    function clickShowMoreButton() {
        const showMoreButton = $('#ui_search_load_more');
        if (showMoreButton.length > 0 && showMoreButton.is(':visible')) {
            console.log('Clicking "Show More" button.');
            showMoreButton.click();
        }
    }

    // Initial run to hide unverified posts and click "Show More" button
    hideUnverifiedPosts();
    clickShowMoreButton();

    // Observer to hide unverified posts and click "Show More" button on new content load
    const observer = new MutationObserver(function(mutations) {
        mutations.forEach(function(mutation) {
            hideUnverifiedPosts();
            clickShowMoreButton();
        });
    });
    observer.observe(document.body, { childList: true, subtree: true });

    // Log to indicate the script is running
    console.log('Hide Unverified Posts userscript is running.');
})(jQuery);
