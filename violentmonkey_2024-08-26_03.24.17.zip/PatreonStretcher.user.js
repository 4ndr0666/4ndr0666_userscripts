// ==UserScript==
// @name         PatreonStretcher
// @namespace    https://github.com/4ndr0666/userscripts
// @version      1.0
// @description  Expand content, adjust layout, and remove unnecessary padding.
// @author       4ndr0666
// @match        *://*.patreon.com/*
// @run-at       document-end
// @icon         data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAYAAACqaXHeAAAAAXNSR0IArs4c6QAAA3tJREFUeF7tmj1s00AUx/8vbjdaOy1MMMDCQBlggoEBJMRE2ZqNBSEisdRRO7A1nVhaxSxIRagDYzu2E0KiAwNMdKAMLDDABG3swtamD10hJRjbd44T+YgvY+757r3ffbyPO0LBf1Rw+2EAmBVQcAJmCxR8AZhDUHkLfJ8ZO9c6aN0hxhUGLum4cgh4w4RXVqm1PLL4472KjkoAAteZY3BdpUNdZBg8X/Z2pTpLAXyrjZ8c4v3PuhiWRo99Gjp1vLH9JekbKYDAHW0wyE0zsC6yBPZsb7eWCYDv2m8BXNDFqJR6bDpecDErAE45qFbijhckrnLpFvBd2wDQakpTKtP3FcCg+bLnJ7qbpuucLoGXGLihoj8Bzw9A1bLnf0qSb7qjdQLNJcn0HYBsgLZyvmvfA7CkAgBA1fGCJyqysi0q0y/zGRAeoOk6V8OKE/MJEFZUDDqSYVSY6Gv4m7Lnb3T+px0AoZxfs1fAmEplsEyYsOo0gkpYTBsAYuY7Z6enEELGd46lFQAivt85Sz2BEDJe9MlMj9uw9QIAfokIhbveDjF9MeiavgDEJu0FhIQ+9AcQAaE57awR8U3ZWffrU16zvd1bRy40dKhqBYBBZ0TAEunnO2ax2zgg5hw5jBNEgEXgj7kGQiJqY8bTOD/PTOsEftZNHEDEtxk0GWkgo0KEu7Losu+BkMqSzlPGADDpsKkHmIKIKYklEMicDud5wquMbbyA8QLGC/TXC4jEhUHrsfU+wioYL1LUA9tbuwrC9YRUusrMk0SUmGD1/QxokXV+vLGz5U/bU//E+53JUFR73CnGqDiPgtXY8trv9sMb61ZrK9dkqE1YlKlIFETavyw1Acm3WqXDkQCyGK8AUG8AvTBeAkFfAEUviha6LP7XbU0RL0baACKvxsBnu4kDGPThv7wai/LLkXGCQhwgS3hyvxhRuR7fro1NDPH+w9gCZ8hKAq2VrNKDkcWdxKduTdepEzjf63HZDOXd3vdQOG8DZeMbAFnrAYFrv9b1aaxs9sXTWdsLLmerCdbsBTBmZINp2U5YdBrBbCYA27VjExZb77Q0UKKUZVkTMk8iLYqKMVTcjW6ACFS3PX9eppcSANGJeDQ9zHuzDBKPoHR9OrtJ4I09Gl6QPZL+k3DKEA14u/IKGFQOBsCgzqyqXWYFqJIaVDmzAgZ1ZlXt+gnhrHFfaCYwZQAAAABJRU5ErkJggg==
// @grant        none
// @license MIT
// @downloadURL https://github.com/4ndr0666/userscripts
// @updateURL https://github.com/4ndr0666/userscripts
// ==/UserScript==
(function() {
    'use strict';

    // Function to set styles on a specific element
    function setElementStyles(element, styles) {
        for (const [property, value] of Object.entries(styles)) {
            element.style.setProperty(property, value, 'important');
        }
    }

    // Select the specific video element using the detailed selector
    const videoElement = document.querySelector("#renderPageContentWrapper > div.sc-1khzwz0-0.jzrvjz > div.sc-ezbkAF.inQWhE > div > div > div > div.sc-50d8t9-1.iPKhhz > div.sc-uivy3g-0.jxwRBR > div > div.sc-jvvksu.jUuDIt > div > div.sc-uivy3g-1.iCldFG > div > div > div > div > div > div > div.sc-1slq1cy-2.NDkDJ > div > div > div > div > video");

    if (videoElement) {
        // Apply styles directly to the video element to stretch it and remove padding
        setElementStyles(videoElement, {
            'max-width': '100%',
            'width': '100%',
            'height': 'auto',
            'padding': '0',
            'margin': '0'
        });

        // Apply similar styles to parent containers to ensure proper stretching
        let parentElement = videoElement.parentElement;
        while (parentElement && parentElement !== document.body) {
            setElementStyles(parentElement, {
                'max-width': '100%',
                'width': '100%',
                'padding': '0',
                'margin': '0',
            });
            parentElement = parentElement.parentElement;
        }

        console.log("Video element found and styles applied.");
    } else {
        console.log("Video element not found.");
    }
})();
