// ==UserScript==
// @name                 Power Forum🔗-Enhancer
// @namespace            https://github.com/utags/links-helper
// @version              1.0.0
// @description          Enhance your browsing experience by converting plain text URLs into hyperlinks, converting image links into images, and parsing Markdown/BBCode into clickable links or images. Now with better UI, user guidance, and script compatibility.
// @author               4ndr0666
// @license              MIT
// @match                https://*/*
// @match                http://*/*
// @run-at               document-start
// @grant                GM.getValue
// @grant                GM.setValue
// @grant                GM_addValueChangeListener
// @grant                GM_notification
// @grant                GM_registerMenuCommand
// @grant                GM_addElement
// ==/UserScript==

(async function () {
  'use strict';

  // Configuration settings
  const config = {
    enableImageLinks: true,
    enableMarkdownBBCodeParsing: true,
    settingsStorageKey: 'links-helper-settings',
  };

  // Error handler with logging and optional user notification
  const handleError = (error, notifyUser = true) => {
    console.error(error);
    if (notifyUser) {
      GM_notification({
        title: 'Links Helper Error',
        text: error.message,
        timeout: 5000,
      });
    }
  };

  // Load settings from storage
  const loadSettings = async () => {
    try {
      const storedSettings = await GM.getValue(config.settingsStorageKey);
      if (storedSettings) {
        Object.assign(config, JSON.parse(storedSettings));
      }
    } catch (error) {
      handleError(new Error('Failed to load settings: ' + error.message));
    }
  };

  // Save settings to storage
  const saveSettings = async (newSettings) => {
    try {
      Object.assign(config, newSettings);
      await GM.setValue(config.settingsStorageKey, JSON.stringify(config));
    } catch (error) {
      handleError(new Error('Failed to save settings: ' + error.message));
    }
  };

  // Create and register settings menu
  const createSettingsMenu = () => {
    GM_registerMenuCommand('Toggle Image Links', () => {
      const newSetting = !config.enableImageLinks;
      saveSettings({ enableImageLinks: newSetting });
      GM_notification({
        title: 'Links Helper',
        text: `Image Links ${newSetting ? 'Enabled' : 'Disabled'}`,
        timeout: 3000,
      });
    });

    GM_registerMenuCommand('Toggle Markdown/BBCode Parsing', () => {
      const newSetting = !config.enableMarkdownBBCodeParsing;
      saveSettings({ enableMarkdownBBCodeParsing: newSetting });
      GM_notification({
        title: 'Links Helper',
        text: `Markdown/BBCode Parsing ${newSetting ? 'Enabled' : 'Disabled'}`,
        timeout: 3000,
      });
    });
  };

  // Convert image URLs to <img> tags
  const processImageURLs = () => {
    document.querySelectorAll('a').forEach(anchor => {
      if (!anchor.__links_helper_processed && /https?:\/\/.*\.(jpg|jpeg|png|gif|bmp|webp|svg)/i.test(anchor.href)) {
        anchor.innerHTML = `<img src="${anchor.href}" alt="image" style="max-width: 100%;">`;
        anchor.__links_helper_processed = true;
      }
    });
  };

  // Convert Markdown and BBCode links to clickable links or images
  const processMarkdownAndBBCode = () => {
    document.querySelectorAll('*:not(a)').forEach(node => {
      if (!node.__links_helper_processed) {
        let text = node.innerHTML;

        // Markdown Image ![alt](url)
        text = text.replace(/!\[([^\]]*)\]\((https?:\/\/[^\s]+)\)/g, '<img src="$2" alt="$1" style="max-width: 100%;">');
        // Markdown Link [text](url)
        text = text.replace(/\[([^\]]+)\]\((https?:\/\/[^\s]+)\)/g, '<a href="$2" target="_blank" rel="noopener">$1</a>');
        // BBCode Image [img]url[/img]
        text = text.replace(/\[img\](https?:\/\/[^\s]+)\[\/img\]/g, '<img src="$1" alt="image" style="max-width: 100%;">');
        // BBCode Link [url]url[/url] or [url=url]text[/url]
        text = text.replace(/\[url\](https?:\/\/[^\s]+)\[\/url\]/g, '<a href="$1" target="_blank" rel="noopener">$1</a>');
        text = text.replace(/\[url=(https?:\/\/[^\s]+)\]([^\[]+)\[\/url\]/g, '<a href="$1" target="_blank" rel="noopener">$2</a>');

        node.innerHTML = text;
        node.__links_helper_processed = true;
      }
    });
  };

  /** Enhanced DOM Observation with Error Handling **/
  const observeDOMChanges = () => {
    try {
      const observer = new MutationObserver((mutationsList) => {
        mutationsList.forEach(mutation => {
          if (mutation.type === 'childList' || mutation.type === 'subtree') {
            if (config.enableImageLinks) processImageURLs();
            if (config.enableMarkdownBBCodeParsing) processMarkdownAndBBCode();
          }
        });
      });

      observer.observe(document.body, {
        childList: true,
        subtree: true,
        characterData: true,
      });

      // Adding a fallback in case of observer failure
      const retryObservation = () => {
        try {
          observer.disconnect();
          observer.observe(document.body, {
            childList: true,
            subtree: true,
            characterData: true,
          });
        } catch (error) {
          handleError(new Error("Failed to re-establish DOM observation: " + error.message));
          // Retry after a delay
          setTimeout(retryObservation, 5000);
        }
      };

      // Listen for observer disconnection or any issues, and attempt to re-observe
      observer.takeRecords = () => {
        retryObservation();
      };

    } catch (error) {
      handleError(new Error("Error during DOM observation: " + error.message));
      // Retry observation after an error
      setTimeout(observeDOMChanges, 5000);
    }
  };

  /** Initialization and Main Function **/
  const init = async () => {
    try {
      await loadSettings();
      createSettingsMenu();

      if (config.enableImageLinks) processImageURLs();
      if (config.enableMarkdownBBCodeParsing) processMarkdownAndBBCode();

      observeDOMChanges();  // Start observing DOM changes

    } catch (error) {
      handleError(error);
    }
  };

  init();

})();