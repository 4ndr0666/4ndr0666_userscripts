// ==UserScript==
// @name        Power Login-Remover
// @namespace   https://4ndr0666.github.io/
// @version     1.0
// @author      4ndr0666
// @description Removes login popups and banners from various social media platforms.
// @match       https://*.facebook.com/*
// @match       https://www.instagram.com/*
// @match       https://m.youtube.com/*
// @match       https://www.youtube.com/*
// @match       https://www.reddit.com/*
// @match       https://twitter.com/*
// @match       https://mobile.twitter.com/*
// @match       https://x.com/*
// @match       https://mobile.x.com/*
// @match       https://*.quora.com/*
// @match       https://ask.fm/*
// @match       https://vk.com/*
// @match       https://m.vk.com/*
// @match       https://*.tumblr.com/*
// @match       https://www.twitch.tv/*
// @match       https://www.tiktok.com/*/video/*
// @include     https://www.pinterest.tld/*
// @grant       GM.getValue
// @grant       GM.setValue
// @grant       GM.registerMenuCommand
// @grant       GM.unsafeWindow
// @license     CC-BY-NC-SA-4.0
// @run-at      document-end
// ==/UserScript==

(function () {
    'use strict';

    // Global Variables
    let disabledSites = [];

    // Program Start
    (async function init() {
        disabledSites = await getDisabledSites();

        // Register toggle for enabling/disabling script per site
        GM.registerMenuCommand(
            disabledSites.includes(location.hostname) ? `Enable again for ${location.hostname}` : `Disable for ${location.hostname}`,
            toggleSiteStatus,
            'T'
        );

        if (!disabledSites.includes(location.hostname)) {
            applyUserCss();
            applySiteSpecificLogic();
        }
    })();

    // Utility Functions
    async function getDisabledSites() {
        const dS = await GM.getValue('disabledSites', '');
        return dS ? dS.split(',') : [];
    }

    function toggleSiteStatus() {
        const hostname = location.hostname;
        if (disabledSites.includes(hostname)) {
            disabledSites = disabledSites.filter(site => site !== hostname);
        } else {
            disabledSites.push(hostname);
        }
        GM.setValue('disabledSites', disabledSites.join(','));
        location.reload();
    }

    // Applies CSS to remove popups
    function applyUserCss() {
        const styles = document.createElement('style');
        styles.id = 'popupRemoverStyles';
        styles.textContent = getSiteSpecificCss();
        document.head.appendChild(styles);

        // Monitor for potential removal of the added CSS and reapply if necessary
        const observer = new MutationObserver(mutations => {
            mutations.forEach(mutation => {
                mutation.removedNodes.forEach(removedNode => {
                    if (removedNode.id === 'popupRemoverStyles') {
                        observer.disconnect();
                        applyUserCss();
                    }
                });
            });
        });

        observer.observe(document.head, { childList: true });
    }

    // CSS Rules based on the current site
    function getSiteSpecificCss() {
        if (location.hostname.includes('instagram.com')) {
            return '.RnEpo.Yx5HN, .RnEpo._Yhr4, .tHaIX, nav.kqZqN.e6AxN, .mray0b6k, [class=x1uhb9sk]{display: none !important} body{overflow-y: scroll !important}';
        } else if (location.hostname.includes('facebook.com')) {
            return '.asf1osic, .tlfeazxf, [role=main]+[data-nosnippet] {display: none !important}';
        } else if (location.hostname.includes('reddit.com')) {
            return '.XPromoNSFWBlockingModal, .XPromoPill, .GetAppFooter {display: none !important}';
        } else if (location.hostname.includes('twitter.com') || location.hostname.includes('x.com')) {
            return '.css-1dbjc4n.r-1kihuf0.r-18u37iz.r-1pi2tsx {display: none !important}';
        } else if (location.hostname.includes('quora.com')) {
            return '.qu-overflow--hidden {overflow-y: scroll !important;}';
        }
        return '';
    }

    // Applies JavaScript-based removals and other site-specific logic
    function applySiteSpecificLogic() {
        if (location.hostname.includes('instagram.com')) {
            handleInstagramPopups();
        } else if (location.hostname.includes('facebook.com')) {
            handleFacebookPopups();
        } else if (location.hostname.includes('reddit.com')) {
            handleRedditPopups();
        } else if (location.hostname.includes('twitter.com') || location.hostname.includes('x.com')) {
            handleTwitterPopups();
        } else if (location.hostname.includes('quora.com')) {
            handleQuoraPopups();
        }
        // Add more sites as needed
    }

    // Site-Specific Logic (Encapsulated in functions for modularity)
    function handleInstagramPopups() {
        const observer = new MutationObserver(mutations => {
            mutations.forEach(mutation => {
                if (mutation.addedNodes.length > 0) {
                    const popup = mutation.addedNodes[0];
                    if (popup.classList.contains('RnEpo') && !popup.querySelector('[name="username"]')) {
                        popup.style.display = 'none';
                    }
                }
            });
        });
        observer.observe(document.body, { childList: true });
    }

    function handleFacebookPopups() {
        const intervalId = setInterval(() => {
            const popup = document.querySelector('.asf1osic');
            if (popup) {
                popup.remove();
                clearInterval(intervalId);
            }
        }, 500);
    }

    function handleRedditPopups() {
        const observer = new MutationObserver(() => {
            document.querySelectorAll('.XPromoNSFWBlockingModal, .GetAppFooter').forEach(el => el.remove());
        });
        observer.observe(document.body, { childList: true, subtree: true });
    }

    function handleTwitterPopups() {
        const observer = new MutationObserver(() => {
            document.querySelectorAll('.css-1dbjc4n.r-1kihuf0').forEach(el => el.remove());
        });
        observer.observe(document.body, { childList: true, subtree: true });
    }

    function handleQuoraPopups() {
        const observer = new MutationObserver(() => {
            document.querySelectorAll('.qu-overflow--hidden').forEach(el => el.classList.remove('qu-overflow--hidden'));
        });
        observer.observe(document.body, { childList: true, subtree: true });
    }

    // Add more site-specific functions here
})();
