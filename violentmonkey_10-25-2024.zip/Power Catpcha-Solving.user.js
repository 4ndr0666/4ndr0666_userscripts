// ==UserScript==
// @name        Power Catpcha-Solving
// @namespace   https://4ndr0666.github.io/
// @include     *
// @grant       none
// @version     1.1
// @author      4ndr0666
// @description Automatically interacts with reCAPTCHA to prove you are not a robot.
// ==/UserScript==

(function() {
    'use strict';

    // Excluded domains where script should not run
    const excludedDomains = ['miped.ru', 'indiegala.com', 'gleam.io'];

    /**
     * Check if the current domain is excluded.
     * @param {string} domain - The domain of the current page.
     * @returns {boolean} True if the domain is excluded, false otherwise.
     */
    function isExcludedDomain(domain) {
        return excludedDomains.some(excluded => domain.includes(excluded));
    }

    /**
     * Interacts with the reCAPTCHA checkbox if found.
     */
    function interactWithRecaptcha() {
        try {
            const recaptchaCheckmark = document.querySelector('.recaptcha-checkbox-checkmark');
            if (recaptchaCheckmark) {
                console.log('[I\'m No Robot] Clicking the reCAPTCHA checkbox.');
                recaptchaCheckmark.click();
            } else {
                console.warn('[I\'m No Robot] reCAPTCHA checkbox not found.');
            }
        } catch (error) {
            console.error('[I\'m No Robot] Error interacting with reCAPTCHA:', error);
        }
    }

    /**
     * Checks if reCAPTCHA has been solved and submits the form.
     */
    function checkForRecaptcha() {
        try {
            if (typeof grecaptcha !== 'undefined') {
                const response = grecaptcha.getResponse();
                if (response.length > 0) {
                    console.log('[I\'m No Robot] reCAPTCHA solved, submitting the form.');
                    document.forms[0].submit();  // Assumes the first form is the one to submit
                }
            }
        } catch (error) {
            console.error('[I\'m No Robot] Error checking reCAPTCHA response:', error);
        }
    }

    /**
     * Main function to initialize the script.
     */
    function main() {
        const domain = window.location.hostname;
        if (!isExcludedDomain(domain)) {
            if (location.href.includes('google.com/recaptcha')) {
                const clickCheck = setInterval(() => {
                    interactWithRecaptcha();
                    clearInterval(clickCheck);
                }, 5000);
            } else {
                document.querySelectorAll('form').forEach(form => {
                    if (form.innerHTML.includes('google.com/recaptcha')) {
                        const solveCheck = setInterval(() => {
                            checkForRecaptcha();
                            clearInterval(solveCheck);
                        }, 100);
                    }
                });
            }
        } else {
            console.log(`[I\'m No Robot] Domain ${domain} is excluded from reCAPTCHA automation.`);
        }
    }

    // Initialize the script when the window is loaded
    window.addEventListener('load', main);

    // Error handling for unexpected issues
    window.addEventListener('error', function(event) {
        console.error('[I\'m No Robot] An error occurred:', event.message);
    });

})();
