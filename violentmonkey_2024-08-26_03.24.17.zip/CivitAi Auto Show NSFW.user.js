// ==UserScript==
// @name         CivitAi Auto Show NSFW
// @namespace    http://irisapp.ca/
// @version      2.1
// @description  Automatically un-blur's CivitAi NSFW posts
// @author       https://github.com/IrisV3rm
// @match        https://civitai.com/*
// @icon         https://civitai.com/favicon.ico
// @grant        none
// @run-at       document-end
// @license MIT
// @downloadURL https://update.sleazyfork.org/scripts/474203/CivitAi%20Auto%20Show%20NSFW.user.js
// @updateURL https://update.sleazyfork.org/scripts/474203/CivitAi%20Auto%20Show%20NSFW.meta.js
// ==/UserScript==

(function() {
    'use strict';
    function unBlur() {
        document.querySelectorAll('.tabler-icon.tabler-icon-eye:not(.tabler-icon-eye-off,mantine-Badge-leftSection)').forEach(element => {
            const parentElement = element.parentElement;
            if (parentElement) {
                if (parentElement.className.includes("mantine-Badge-leftSection")) return;
                if (element.attributes["stroke-width"].value != 2.5) return;
                parentElement.click();
            }
        });
    }
    new MutationObserver(unBlur).observe(document.body, { childList: true, subtree: true, attributes: true});
    unBlur();
})();