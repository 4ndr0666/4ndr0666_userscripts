// ==UserScript==
// @name        Power Safesearch_and_Telemetry-Killer
// @namespace   https://4ndr0666.github.io/
// @description Disables SafeSearch on Google and Yandex, sets region and language, and handles license agreements.
// @match       *://*.google.com/*
// @match       *://*.google.co.in/*
// @match       *://*.google.co.uk/*
// @match       *://*.google.com.au/*
// @match       *://*.google.ca/*
// @match       *://*.google.co.nz/*
// @match       *://*.google.com.sg/*
// @match       *://*.google.com.my/*
// @match       *://*.google.co.za/*
// @match       *://*.google.com.hk/*
// @match       *://*.google.co.jp/*
// @match       *://*.google.de/*
// @match       *://*.google.fr/*
// @match       *://*.google.it/*
// @match       *://*.google.es/*
// @match       *://*.google.nl/*
// @match       *://*.google.com.br/*
// @match       *://*.google.com.mx/*
// @match       *://*.google.ru/*
// @match       *://*.google.pl/*
// @match       *://*.google.se/*
// @match       *://*.google.no/*
// @match       *://*.google.dk/*
// @match       *://*.google.fi/*
// @match       *://*.google.ie/*
// @match       *://*.google.gr/*
// @match       *://*.google.pt/*
// @match       *://*.google.at/*
// @match       *://*.google.be/*
// @match       *://*.google.cz/*
// @match       *://*.google.sk/*
// @match       *://*.google.hu/*
// @match       *://*.google.co.kr/*
// @match       *://*.google.ro/*
// @match       *://*.google.co.il/*
// @match       *://*.google.co.id/*
// @match       *://*.google.ae/*
// @match       *://*.google.com.tr/*
// @match       *://*.google.com.sa/*
// @match       *://*.google.com.vn/*
// @match       *://*.google.com.eg/*
// @match       *://*.google.com.ph/*
// @match       *://*.google.com.ar/*
// @match       *://*.google.com.uy/*
// @match       *://*.google.com.pe/*
// @match       *://*.google.com.ve/*
// @match       *://*.google.lk/*
// @match       *://*.google.com.pk/*
// @match       *://*.google.com.ng/*
// @match       *://*.google.com.gh/*
// @match       *://*.google.co.tz/*
// @match       *://*.google.co.ke/*
// @match       *://*.google.com.co/*
// @match       *://*.google.com.bo/*
// @match       *://*.google.cl/*
// @match       *://*.google.com.ec/*
// @match       *://*.google.co.cr/*
// @match       *://*.google.com.cu/*
// @match       *://*.google.co.ma/*
// @match       *://*.google.sn/*
// @match       *://*.google.rw/*
// @match       *://*.google.et/*
// @match       *://*.google.mu/*
// @match       *://*.google.com.bh/*
// @match       *://*.google.com.kw/*
// @match       *://*.google.com.qa/*
// @match       *://*.google.com.om/*
// @match       *://*.yandex.com/*
// @match       *://*.yandex.ru/*
// @match       *://*.yandex.by/*
// @match       *://*.yandex.kz/*
// @match       *://*.yandex.ua/*
// @match       *://*.yandex.uz/*
// @match       *://*.yandex.com.tr/*
// @match       *://*.yandex.tj/*
// @match       *://*.yandex.am/*
// @match       *://*.yandex.ge/*
// @match       *://*.yandex.az/*
// @grant       none
// @version     1.1
// @run-at      document-start
// @author      4ndr0666
// ==/UserScript==

(function() {
    'use strict';

    /**
     * Disable SafeSearch on Google and Yandex by modifying URL parameters.
     */
    function disableSafeSearch() {
        try {
            const url = new URL(window.location.href);
            const params = url.searchParams;
            let shouldReload = false;

            // Disable SafeSearch on Google
            if (window.location.hostname.includes('google')) {
                if (params.get('safe') !== 'off') {
                    params.set('safe', 'off');
                    shouldReload = true;
                }
            }

            // Disable SafeSearch on Yandex
            if (window.location.hostname.includes('yandex')) {
                if (params.get('lr') !== '0') { // Yandex uses 'lr' for SafeSearch settings
                    params.set('lr', '0');
                    shouldReload = true;
                }
            }

            // Reload page if parameters were modified
            if (shouldReload && window.location.href !== url.href) {
                window.location.href = url.href;
            }
        } catch (error) {
            console.error('[Safesearch and Telemetry Killer] Failed to disable SafeSearch:', error);
        }
    }

    /**
     * Set Google search region to US and language to English.
     */
    function setGoogleRegionToUS() {
        try {
            const url = new URL(window.location.href);
            const params = url.searchParams;
            let shouldReload = false;

            // Set Google language to English and region to US
            if (window.location.hostname.includes('google')) {
                if (params.get('hl') !== 'en') {
                    params.set('hl', 'en'); // Set language to English
                    shouldReload = true;
                }
                if (params.get('gl') !== 'us') {
                    params.set('gl', 'us'); // Set region to US
                    shouldReload = true;
                }
            }

            // Reload page if parameters were modified
            if (shouldReload && window.location.href !== url.href) {
                window.location.href = url.href;
            }
        } catch (error) {
            console.error('[Safesearch and Telemetry Killer] Failed to set region and language:', error);
        }
    }

    /**
     * Automatically accept license agreements on Google.
     */
    function acceptLicenseAgreement() {
        try {
            setTimeout(() => {
                const acceptButton = document.querySelector('#L2AGLb.tHlp8d');
                if (acceptButton) {
                    acceptButton.click();
                    console.log('[Safesearch and Telemetry Killer] License agreement accepted.');
                }
            }, 200); // Adjust delay if necessary
        } catch (error) {
            console.error('[Safesearch and Telemetry Killer] Failed to accept license agreement:', error);
        }
    }

    /**
     * Initialize the script by executing functions based on the current website.
     */
    function init() {
        if (window.location.hostname.includes('google')) {
            acceptLicenseAgreement();
            setInterval(setGoogleRegionToUS, 500); // Continuously ensure region and language are set correctly
        }

        if (window.location.hostname.includes('google') || window.location.hostname.includes('yandex')) {
            disableSafeSearch(); // Disable SafeSearch on Google and Yandex
        }
    }

    // Initialize the script
    init();
})();
